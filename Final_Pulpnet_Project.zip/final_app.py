from sentence_transformers import SentenceTransformer, util
from transformers import pipeline
import torch
import streamlit as st

#Loading dataset
with open("chemineers_events_dataset.txt", "r", encoding="utf-8") as f:
    corpus = f.read().split("\n\n---\n\n")  

semantic_model = SentenceTransformer("all-MiniLM-L6-v2")  # for semantic search
qa_model = pipeline("question-answering", model="deepset/roberta-base-squad2")  # for answer extraction

# for embeddings 
corpus_embeddings = semantic_model.encode(corpus, convert_to_tensor=True)

def get_response(query):
    query_embedding = semantic_model.encode(query, convert_to_tensor=True)
    scores = util.pytorch_cos_sim(query_embedding, corpus_embeddings)[0]
    best_idx = torch.argmax(scores).item()
    best_context = corpus[best_idx]

    qa_result = qa_model({
        "question": query,
        "context": best_context
    })
    
    if qa_result["score"] > 0.3 and qa_result["answer"].strip() != "":
        return f" Answer: {qa_result['answer']}"
    else:
        return f" Info:\n{best_context}"
    
#now streamlit
st.set_page_config(page_title="IITK Chemineers Assistant", layout="centered")
st.title("IIT Kanpur Chemineers Assistant")
st.markdown("Ask about *Exergy*, *Simutech*, *Intern Connect*, etc.")

user_input = st.text_input("Ask a question:", placeholder="e.g. When was Exergy inaugurated?")

if user_input:
    response = get_response(user_input)
    st.markdown("### Response")
    st.write(response)
